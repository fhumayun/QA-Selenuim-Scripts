# CREATE BGLs


# IMPORT USER'S OPTIONS
   BGNAME="CMP_Automation"
   offcode="302108187"
   startBGLNo=300
   stopBGLNo=301
   
   countrycode="+ 30"
   areacode=" (210) "
   oc="8187"
        

###########################################
# Create Mass Provisioning File   	      #
###########################################
echo "Creating Mass Provisioning File in /tmp/tempfile. . ."

rm -f /tmp/tempfile

echo "FILE VERSION:11.00.01:MP2" >> /tmp/tempfile

i=$startBGLNo
while [ $i -le $stopBGLNo ]; do

echo "CS_SIP" >> /tmp/tempfile
echo ",SUBSCRIBERDN=\"${offcode}$i\"" >> /tmp/tempfile
echo ",BILLINGID=\"${offcode}$i\"" >> /tmp/tempfile
echo ",NUMBERPLANNAME=\"NP_${BGNAME}$j\"" >> /tmp/tempfile
echo ",BGNAME=\"${BGNAME}$j\"" >> /tmp/tempfile
echo ",DISPLAYNAME=\"${countrycode}${areacode}${oc}$i\"" >> /tmp/tempfile
echo ",UNICODEDISPLAYNAME=\"\"" >> /tmp/tempfile
echo ",PHONENAME=\"${offcode}$i\"" >> /tmp/tempfile
echo ",REGTYPE=\"Dynamic\"" >> /tmp/tempfile
echo ",ANAT_SUPPORT=\"AnatAuto\"" >> /tmp/tempfile
echo ",SENDINSECUREREFFEREDBYHEADER=0" >> /tmp/tempfile
echo ";;" >> /tmp/tempfile
echo "" >> /tmp/tempfile

echo "UMB" >> /tmp/tempfile
echo ",SUBSCRIBERDN=\"${offcode}$i\"" >> /tmp/tempfile
echo ",BGLINENAME=\"${countrycode}${areacode}${oc}$i\"" >> /tmp/tempfile
echo ",BGEXTENSION=\"$i\"" >> /tmp/tempfile
echo ";;" >> /tmp/tempfile
echo "" >> /tmp/tempfile

    ((i=i+1))
done

#MassProvisioning
su - srx -c "/unisphere/srx3000/UNSPsubp/soapMassProv -pass=hiq8000 -o=siemens -f=/tmp/tempfile"
echo "Mass Provisioning ended"
