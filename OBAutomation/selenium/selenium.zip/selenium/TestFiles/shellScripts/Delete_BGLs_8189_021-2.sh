# Delete BGLs

# IMPORT USER'S OPTIONS
   BGNAME="Comparison_BG"
   offcode="302108189"
   startBGLNo=021
   stopBGLNo=022

###########################################
# Create Mass Provisioning File   	      #
###########################################
echo "Creating Mass Provisioning File in /tmp/tempfile8189. . ."

rm -f /tmp/tempfile8189

echo "FILE VERSION:11.00.01:MP2" >> /tmp/tempfile8189

j=$startBGLNo 	
while [ $j -le $stopBGLNo ]; do

echo "RS" >> /tmp/tempfile8189
echo ",SUBSCRIBERDN=\"${offcode}$j\"" >> /tmp/tempfile8189
echo ";;" >> /tmp/tempfile8189

    ((j=j+1))
done

su - srx -c "/unisphere/srx3000/UNSPsubp/soapMassProv -pass=hiq8000 -o=siemens -f=/tmp/tempfile8189"
echo "Mass Provisioning ended"