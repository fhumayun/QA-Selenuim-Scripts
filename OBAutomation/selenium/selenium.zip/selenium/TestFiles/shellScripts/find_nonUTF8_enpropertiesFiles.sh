#!/bin/bash

#deployment directory
DEPLOYMENT=/opt/siemens

if `test -d /tmp/zips`; then
    rm -rf /tmp/zips/*
else
    mkdir /tmp/zips 
fi

count=0
for i in $(find $DEPLOYMENT -name *.jar)
do
	PROPERTIES_FOUND=`unzip $i *en.properties -d /tmp/zips/$count`
	#echo "Properties found: $PROPERTIES_FOUND"
let "count+=1"
done
cd /tmp/zips/
file `find $DEPLOYMENT -name *en.*` | awk '!/UTF/' | grep com/siemens/symphonia >> results.txt
#Display Results
cat /tmp/zips/results.txt
