# Delete BGLs

# IMPORT USER'S OPTIONS
   BGNAME="Comparison_BG"
   offcode="302108187"
   startBGLNo=900
   stopBGLNo=901

###########################################
# Create Mass Provisioning File   	      #
###########################################
echo "Creating Mass Provisioning File in /tmp/tempfile818790. . ."

rm -f /tmp/tempfile818790

echo "FILE VERSION:11.00.01:MP2" >> /tmp/tempfile818790

j=$startBGLNo 	
while [ $j -le $stopBGLNo ]; do

echo "RS" >> /tmp/tempfile818790
echo ",SUBSCRIBERDN=\"${offcode}$j\"" >> /tmp/tempfile818790
echo ";;" >> /tmp/tempfile818790

    ((j=j+1))
done

su - srx -c "/unisphere/srx3000/UNSPsubp/soapMassProv -pass=hiq8000 -o=siemens -f=/tmp/tempfile818790"
echo "Mass Provisioning ended"