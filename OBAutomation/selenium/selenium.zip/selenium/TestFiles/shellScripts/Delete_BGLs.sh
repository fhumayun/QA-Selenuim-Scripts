# Delete BGLs

# IMPORT USER'S OPTIONS
   BGNAME="CMP_Automation"
   offcode="3021081870"
   startBGLNo=21
   stopBGLNo=49

###########################################
# Create Mass Provisioning File   	      #
###########################################
echo "Creating Mass Provisioning File in /tmp/tempfile. . ."

rm -f /tmp/tempfile

echo "FILE VERSION:11.00.01:MP2" >> /tmp/tempfile

j=$startBGLNo 	
while [ $j -le $stopBGLNo ]; do

echo "RS" >> /tmp/tempfile
echo ",SUBSCRIBERDN=\"${offcode}$j\"" >> /tmp/tempfile
echo ";;" >> /tmp/tempfile 

    ((j=j+1))
done

su - srx -c "/unisphere/srx3000/UNSPsubp/soapMassProv -pass=hiq8000 -o=siemens -f=/tmp/tempfile"
echo "Mass Provisioning ended"

