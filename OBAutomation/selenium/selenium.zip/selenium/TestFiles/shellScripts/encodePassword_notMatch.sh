#!/bin/sh

echo
expect -c "
spawn /opt/siemens/servicetools/cmp/encodePassphrase.sh   
expect *Provide { send aa\n }
expect *Repeat { send bb\n }
   interact
   exit
" >> encodeNotMatch.txt
