#!/bin/sh

echo
expect -c "
spawn /opt/siemens/servicetools/cmp/encodePassphrase.sh   
expect *Provide { send \n }
expect *Repeat { send \n }
   interact
   exit
" >> encodeEmpty.txt
