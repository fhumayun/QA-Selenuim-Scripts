#!/bin/sh

echo
expect -c "
spawn /opt/siemens/servicetools/cmp/encodePassphrase.sh   
expect *Provide { send Asd123!.\n }
expect *Repeat { send Asd123!.\n }
   interact
   exit
" >> encodeValid.txt
