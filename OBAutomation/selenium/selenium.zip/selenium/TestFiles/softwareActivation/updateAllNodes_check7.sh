#!/bin/bash
###############################################################################
# Copyright (c) 2008-2010 Siemens Enterprise Communications GmbH & Co. KG     #
# All rights reserved.                                                        #
# This software is the confidential and proprietary information of            #
# Siemens Enterprise Communications GmbH & Co. KG, Germany                    #
#                                                                             #
# Siemens Enterprise Communications GmbH & Co. KG is a Trademark Licensee     #
# of Siemens AG                                                               #
#                                                                             #
# Copying of this document, or giving it to others, or the use or             #
# communication of the contents thereof, is forbidden without prior           #
# written authorization.  The copyright notice hereon shall not               #
# constitute or imply publication.                                            #
###############################################################################

# updateAllNodes.sh
#
# History: Initial version (wiki6268_Feature.UiForPatchingOfApplications)


################################## Parameters #################################

VERBOSE=0
SYNCH=0

# source symphonia environment
SYSCONFIG=/etc/sysconfig/siemens/symphonia
[ ! -r $SYSCONFIG ] && echo "Symphonia environment is damaged. Aborting!" && exit 99 
source $SYSCONFIG

SYSTEM_FILE="${SYMPHONIA_FW}/conf/system.xml"
RESPONSE_FILE="${SYMPHONIA_INSTALL}/conf/responsefile.txt"

SCRIPTNAME=`basename $0 | cut -d. -f 1`
FULLSCRIPTNAME="`pwd`/`basename $0`"

declare -r TRUE=0
declare -r FALSE=1

BACKEND=""
FRONTENDS=( )
MEDIASERVERS=( )
NODES=( )

SETUP_STRING_VERSION=""

FEATURE_LOCK="${SYMPHONIA_LOG}/install/.featureUIpatching.lock"
PARTITION_LOCK="/etc/osc-setup/syncUC_config"
SYNCH_REPO=""

# hardcoded paths
BASE_REPO="/OSCbase"
UPDATE_REPO="/OSCupdate"
UPDATE_LOGFILE="${SYMPHONIA_LOG}/0update.log"
UPDATE_STATUSFILE="${SYMPHONIA_LOG}/oscUpdateStatusFile"
COLLECTDIR="${SYMPHONIA_LOG}/install/uipatching"
STATUS_FILE="$COLLECTDIR/updateAllNodes.status"
ULOGFILE="$COLLECTDIR/updateAllNodes.log"
SLOGFILE="$COLLECTDIR/status.log"
CLOGFILE="$COLLECTDIR/check.log"
ARGFILE="$COLLECTDIR/argHistory.txt"
REPORT="/var/tmp/softwareActivation_logFiles.tar"

SYNC_FAIL=0
SINGLE_NODE=0

############################### Help functions ###############################

# basic setup
setupLog()
{
   if [[ ! -d $COLLECTDIR ]]; then
      #Creating uipatching directory to store logfiles
      mkdir $COLLECTDIR 2>/dev/null
   fi
   rm -rf $LOGFILE 1>/dev/null 2>&1
   logInfo "#################### EXECUTION OF $0 STARTS ####################"
} # end: setupLog

# delete history
deleteHistory()
{
   rm -rf $REPORT $STATUS_FILE $UPDATE_STATUSFILE 1>/dev/null 2>&1
   for (( i = 0 ; i < ${#NODES[@]} ; i++ ))
   do
     ssh root@${NODES[$i]} "rm -rf ${UPDATE_STATUSFILE}" 1>>$LOGFILE 2>&1
   done
   
   # valid arguments to store
   local option_val=""
   # only when new repo is given (not resume)
   if [ -n "$REPOSITORY" ]; then
     if [ "$SYNCH" -eq 1 ]; then
        option_val="-s"
     fi
     echo "option=$option_val" > $ARGFILE
     echo "path=$REPOSITORY" >> $ARGFILE
   fi

} # end: deleteHistory

# update log cleanup
updateLogCleanup()
{
   LOGFILE="$ULOGFILE"
   setupLog
} # end: updatelogCleanup

# status log cleanup
statusLogCleanup()
{
   LOGFILE="$SLOGFILE"
   setupLog
} # end: statuslogCleanup

# check log cleanup
checkLogCleanup()
{
   LOGFILE="$CLOGFILE"
   setupLog
} # end: checklogCleanup

# basic log
log()
{
   type=$1
   msg="$2"
   date=`date +%Y/%m/%d-%H:%M:%S`
   echo -e "$date # $type = $msg" 1>>$LOGFILE
}

# log info
logInfo()
{
   log INFO "$1"
} # end: logInfo

# log warnings
logWarn()
{
   log WARN "$1"
} # end: logWarn

# log debug
logDebug()
{
   if [ $VERBOSE -eq 1 ]; then
      log DEBUG "$1"
   fi
} # end: logDebug

# log update status/check to CMP
logStatus()
{
   code="$1"
   msg="$2"
   logInfo "'$msg' (error code $code)"
   logInfo "#################### EXECUTION OF $0 ENDED ####################"
   exit $code 
}

# log update report to CMP
logReport()
{
   code="$1"
   msg="$2"
   removeMsgOftheDay
   collectLogs
   logInfo "'$msg' (error code $code)"
   logInfo "#################### EXECUTION OF $0 ENDED ####################"
   exit $code
}

# usage
usage()
{
cat << EOF

NAME
    $SCRIPTNAME - call update scripts for all nodes of a small/duplex deploment.

SYNOPSIS
    $SCRIPTNAME [OPTION] <command> [ARGS]

DESCRIPTION
    Call actual update scripts in all nodes of a small/duplex deploment 
    after checking some prerequisities.

OPTIONs:
    -v     be verbose.
    -h     print usage.
    -s     synch active-fallback partitions   

COMMANDs:
    check  <no args>
           check if feature activated

    check  <path of repository>
           Check necessary prerequisites for the update using the path to the new software delivery provided as YUM repository.

    update <no args>
           If the path to the new software delivery is not provided,
           try to update the system using the already existing repositories on the backend.

    update <path of repository>
           Start the update using the path to the new software delivery provided as YUM repository
           Providing the path to new software as parameter is optional. If not provided, 
           it will try to update the system using the already existing repositories on the backend. 

    status <no args>
           Check the status of the update 

EOF

exit $1

} # usage

# retrieve a parameter value from a system file
getParamFromSystemfile () 
{
   logDebug "Entering function '$FUNCNAME'..."
   ENTRIES=`exec perl ${SYMPHONIA_INSTALL}/bin/srvXMLparser.pl`

   arrFrond=0
   arrMed=0
   STR=""
   i=0

   for EACH in $ENTRIES; do
      STR+="$EACH "
      i=`expr $i + 1`

      if [ $i -eq 2 ]; then
         if [[ $STR =~ "BACKEND" ]]; then
            BACKEND=`echo $STR | cut -d'=' -f2 | awk '{ print $1 }'`
            logInfo "Reading backend node (BE) info: $BACKEND (BACKEND)"
         fi

         if [[ $STR =~ "FRONTEND" ]]; then
            FRONTENDS[arrFrond]=`echo $STR | cut -d'=' -f2 | awk '{ print $1 }'`
            NTYPES[arrFrond]="FRONTEND"
            logInfo "Reading frontend $arrFrond node (FE) info: ${FRONTENDS[arrFrond]} (${NTYPES[arrFrond]})"
            arrFrond=`expr $arrFrond + 1`
         fi

         if [[ $STR =~ "MEDIASERVER" ]]; then
            MEDIASERVERS[arrMed]=`echo $STR | cut -d'=' -f2 | awk '{ print $1 }'`
            NTYPES[`expr $arrFrond + $arrMed`]="MEDIASERVER"
            logInfo "Reading media server $arrMed node (MS) info: ${MEDIASERVERS[arrMed]} (${NTYPES[`expr $arrFrond + $arrMed`]})"
            arrMed=`expr $arrMed + 1`
         fi

         STR=""
         i=0
      fi

   done

   if [ "${#FRONTENDS[@]}" -eq 0 ]; then 
        logInfo "No frontend nodes (FE) found" 
   fi
   
   if [ "${#MEDIASERVERS[@]}" -eq 0 ]; then
        logInfo "No media server nodes (MS) found"
   fi

   NODES=("${FRONTENDS[@]}" "${MEDIASERVERS[@]}") # concatenate the two arrays

   if [ "${#NODES[@]}" -eq 0 ]; then
      logInfo "Single node installation, skip all steps related to remote nodes"
      SINGLE_NODE=1
   fi

   logDebug "Returning from function '$FUNCNAME'..."
   return 0
}


# gets the version of the installed OpenScape product. Stores the information in the following variables:

# example : 'OpenScape UC - ProductVersion' version: 'V5 R0.3.5'    build: '080005_1'
# VERSION (ex: 5), RELEASE_MAJOR (ex: 0), RELEASE_MAJOR (ex: 0), RELEASE_MINOR (ex: 3)
# DVD (ex: 8), HOTFIX_MAJOR (ex: 5), HOTFIX_MINOR (ex: 1)(default: 0)

getInstalledVersion()
{
   logDebug "Entering function '$FUNCNAME'..."

   local INVENTORY="$SYMPHONIA_HOME/common/bin/productInventory.sh"
   local INVENTORY_REGEXP="^'OpenScape UC - ProductVersion'	version: 'V0*([0-9]+) R0*([0-9]+)\.0*([0-9]+)\.[0-9]+'	build: '([0-9][0-9])0*([0-9]+)(_([0-9]+))?'"

    # example : TEMP: 'OpenScape UC - ProductVersion' version: 'V5 R0.3.5'    build: '080005_1'
   local TEMP

   if TEMP=$($INVENTORY -t | egrep "$INVENTORY_REGEXP"); then
        # INST_VERSION = 5
        INSTALLED_VERSION=$(echo "$TEMP" | sed -r "s/$INVENTORY_REGEXP/\1/;s/\b0*([0-9])/\1/g" )

        # INST_RELEASE = 0
        INSTALLED_RELEASE_MAJOR=$(echo "$TEMP" | sed -r "s/$INVENTORY_REGEXP/\2/;s/\b0*([0-9])/\1/g" )

        # INST_RELEASEMINOR = 3
        INSTALLED_RELEASE_MINOR=$(echo "$TEMP" | sed -r "s/$INVENTORY_REGEXP/\3/;s/\b0*([0-9])/\1/g" )

        # INST_DVD = 8
        INSTALLED_DVD=$(echo "$TEMP" | sed -r "s/$INVENTORY_REGEXP/\4/;s/\b0*([0-9])/\1/g" )

        # INST_HOTFIX_MAJOR = 5
        INSTALLED_HOTFIX_MAJOR=$(echo "$TEMP" | sed -r "s/$INVENTORY_REGEXP/\5/;s/\b0*([0-9])/\1/g" )

        INSTALLED_HOTFIX_MINOR=$(echo "$TEMP" | sed -r "s/$INVENTORY_REGEXP/\7/;s/\b0*([0-9])/\1/g" )
        if [ -z $INST_HOTFIX_MINOR ]; then
            # INST_HOTFIX_MINOR = 0
            INSTALLED_HOTFIX_MINOR=0
        fi
   else
        logWarn "Pattern does not match to ProductInventory"
        return 99
   fi
   
   logInfo "Determining installed Version = V$INSTALLED_VERSION R$INSTALLED_RELEASE_MAJOR.$INSTALLED_RELEASE_MINOR DVD$INSTALLED_DVD Hotfix:$INSTALLED_HOTFIX_MAJOR.$INSTALLED_HOTFIX_MINOR"

   logDebug "Returning from function '$FUNCNAME'..."
}


# gets the Installer-Version and defines Variables:
# example: noarch/OpenScapeUC_ProductVersion-5_0.3.5-80005_1.noarch.rpm
# VERSION (ex.: 5), RELEASE_MAJOR (ex.: 0), RELEASE_MINOR (ex.: 3), DVD (ex.: 8), HOTFIX_MAJOR (ex.: 5), HOTFIX_MINOR (ex.: 1) (default: 0)

getSetupVersion () 
{
    logDebug "Entering function '$FUNCNAME'..."    

    if [ -z $REPOSITORY ]; then
      REPOSITORY=$SYNCH_REPO
    fi    

    local SETUP_FILENAMEPATTERN="$REPOSITORY/noarch/OpenScapeUC_ProductVersion-*.noarch.rpm"
    local SETUP_REGEXP="$REPOSITORY/noarch/OpenScapeUC_ProductVersion-0*([0-9]+)_0*([0-9]+)\.([0-9]+)\.[0-9]+-([0-9][0-9])0*([0-9]+)(_([0-9]+))?\.noarch\.rpm"

    local SETUP_FILENAME=$(ls $SETUP_FILENAMEPATTERN 2>/dev/null)

    if [ -z $SETUP_FILENAME ]; then
       logWarn "Cannot find OpenScapeUC_ProductVersion file"
       return 99 
    elif [ $(echo "$SETUP_FILENAME" | wc -l) -ne 1 ]; then
        logWarn "Found more than one OpenScapeUC_ProductVersion files"
        return 99
    fi

    #test if pattern matches
    if (echo $SETUP_FILENAME | egrep "$SETUP_REGEXP" > /dev/null); then
        # try to read version from rpm name, example: noarch/OpenScapeUC_ProductVersion-5_0.3.5-80005.noarch.rpm
        # example: SETUP_VERSION=5
        SETUP_VERSION=$(echo "$SETUP_FILENAME" | sed -r "s#$SETUP_REGEXP#\1#;s#\b0*([0-9])#\1#g")

        # example: SETUP_RELEASE=0
        SETUP_RELEASE_MAJOR=$(echo "$SETUP_FILENAME" | sed -r "s#$SETUP_REGEXP#\2#;s#\b0*([0-9])#\1#g")

        # example: SETUP_RELEASE_MINOR=3
        SETUP_RELEASE_MINOR=$(echo "$SETUP_FILENAME" | sed -r "s#$SETUP_REGEXP#\3#;s#\b0*([0-9])#\1#g")

        # example: SETUP_DVD=8
        SETUP_DVD=$(echo "$SETUP_FILENAME" | sed -r "s#$SETUP_REGEXP#\4#;s#\b0*([0-9])#\1#g")

        # example: SETUP_HOTFIX_MAJOR=5
        SETUP_HOTFIX_MAJOR=$(echo "$SETUP_FILENAME" | sed -r "s#$SETUP_REGEXP#\5#;s#\b0*([0-9])#\1#g")

        # example: SETUP_HOTFIX_MINOR=
        SETUP_HOTFIX_MINOR=$(echo "$SETUP_FILENAME" | sed -r "s#$SETUP_REGEXP#\7#;s#\b0*([0-9])#\1#g")

        if [ -z $SETUP_HOTFIX_MINOR ]; then
            # example: SETUP_HOTFIX_MINOR = 0
            SETUP_HOTFIX_MINOR=0
        fi
    else
        logWarn "Pattern does not match to ProductVersion-Package"
        return 99
    fi
    
    SETUP_STRING_VERSION="V$SETUP_VERSION R$SETUP_RELEASE_MAJOR.$SETUP_RELEASE_MINOR DVD$SETUP_DVD Hotfix:$SETUP_HOTFIX_MAJOR.$SETUP_HOTFIX_MINOR"
    logInfo "Determining Version on repository path = $SETUP_STRING_VERSION"

    logDebug "Returning from function '$FUNCNAME'..."
}

############################### Main functions ################################


# check if we are running as root 
isRootUser()
{
    logDebug "Entering function '$FUNCNAME'..."

    userID=`id | grep -c root`
    if [ $userID = 0 ]; then 
        logStatus 2 "Must be running as ROOT user, environment is not prepared properly for the update from CMP, aborting!!!"
    else 
        logInfo "Running as ROOT user, continue..."
    fi

    logDebug "Returning from function '$FUNCNAME'..."
} # end: isRootUser 


# check if updateAllNodes script already running with command update
checkUpdateRunning()
{
    logDebug "Entering function '$FUNCNAME'..."

    local myPID=$$
    local INSTANCES="/tmp/instances.txt"
    logInfo "Checking if an update is already in progress"

    ps -ef | grep 'updateAllNodes.sh' | grep bash | grep -v $myPID | grep -v grep >$INSTANCES 
    #cat $INSTANCES 1>>$LOGFILE
    while read line; do 
      logDebug "Checking line :'$line'"
      local pid=`echo $line | awk '{ print $2 }'`
      local started=`echo $line | awk '{ print $5 }'`
      local arg1=`echo $line | awk '{ print $10 }'`
      local arg2=`echo $line | awk '{ print $11 }'`
 
     # /update/update repo/-s update/-s update repo/
      if [ "$arg1" == "update" ] || [ "$arg2" == "update" ]; then
        logWarn "Script updateAllNodes.sh already running with update argument (started at $started with pid $pid)" 
        return 1
      fi
    done < $INSTANCES
    
    logInfo "No instance of script updateAllNodes.sh running with update argument"

    rm -rf $INSTANCES 1>>$LOGFILE 2>&1

    logDebug "Returning from function '$FUNCNAME'..."
} # end: checkUpdateRunning


notUpdateRunning()
{
    logDebug "Entering function '$FUNCNAME'..."

    checkUpdateRunning
    ret=$?
    if [ "$ret" -eq 0 ]; then
       logInfo "Not update in progress, continue..."
    elif [ "$ret" -eq 1 ]; then
       logStatus 1 "Another update in progress"
    fi

    logDebug "Returning from function '$FUNCNAME'..."
}


# check that each node FE/MS has access to the repositories on the backend using http  
# equivelant to verifyHttp of prepareUpdate script
checkYumAccess()
{
    logDebug "Entering function '$FUNCNAME'..."

    if [ "$SINGLE_NODE" -eq 1 ]; then
       logDebug "None remote node found, skip this check"
       return
    fi

    logInfo "Verify that every remote node has HTTPS access to repositories"
    
    local CURLOUT="/tmp/curlout.log"
    local CACERT="/etc/ssl/certs/backend_sen_cacert.pem"

    local LOCAL=""
    if [[ $BACKEND =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]];then
      LOCAL=`hostname -f`
    else
      LOCAL=$BACKEND
    fi

    for (( i = 0 ; i < ${#NODES[@]} ; i++ ))
    do
      for REPOS in $BASE_REPO $UPDATE_REPO
      do
         ssh root@${NODES[$i]} "curl --cacert $CACERT --head https://$LOCAL:444$REPOS/" 1>$CURLOUT 2>/dev/null
         ret_val="$?"
         if [ $ret_val -ne 0 ]; then
            cat $CURLOUT 1>>$LOGFILE 2>&1
            logStatus 8 "Cannot access node ${NODES[$i]} to check access to YUM repositories"
        else
            ret=`cat $CURLOUT | grep HTTP | awk '{ print $2 }'`
            if [ $ret -ne 200 ]; then
               logStatus 4 "Node ${NODES[$i]} does not have HTTPS access to '$REPOS' repository"
            else
               logInfo "Node ${NODES[$i]} has HTTPS access to '$REPOS' repository, continue..."
            fi
        fi
      done
      rm -rf $CURLOUT >>$LOGFILE 2>&1
    done
   
    logDebug "Returning from function '$FUNCNAME'..."
} # end: checkYumAccess


# check path to new software      
# check installed version, version to setup and if the version to be installed is newer or equal than the installed version
checkSwPath()
{
    logDebug "Entering function '$FUNCNAME'..."

    if [ ! -d "$REPOSITORY" ]; then 
       logStatus 5 "Path to new software not found, directory $REPOSITORY does not exist"
    else
       logInfo "Location $REPOSITORY exists on system, continue..."
    fi

    if [ -f $REPOSITORY/support/update.sh ]; then
       logInfo "Actual update script to call exists in $REPOSITORY/support folder, continue..."
    else
       logStatus 5 "Update script could not found in $REPOSITORY/support folder"
    fi

    if ! getInstalledVersion; then
       logStatus 8 "Could not detect installed version, aborting!!!"
    fi
   
    if ! getSetupVersion; then
       logStatus 6 "Could not detect setup version, path to new software does not contain a valid repository" 
    fi

    local SKIP_FURTHER_CHECKS=2 
    
    if [ $SETUP_VERSION -ge $INSTALLED_VERSION ]; then
        if [ $SETUP_VERSION -ne $INSTALLED_VERSION ]; then
            SKIP_FURTHER_CHECKS=0
        fi
    else
        logStatus 7 "Update is not supported for installed Version"
    fi
    
    if [ $SKIP_FURTHER_CHECKS -eq 0 ] || [ $SETUP_RELEASE_MAJOR -ge $INSTALLED_RELEASE_MAJOR ]; then
        if [ $SETUP_RELEASE_MAJOR -ne $INSTALLED_RELEASE_MAJOR ]; then
            SKIP_FUTHER_CHECKS=0
        fi
    else
        logStatus 7 "Update is not supported for installed Release"
    fi
    
    if [ $SKIP_FURTHER_CHECKS -eq 0 ] || [ $SETUP_RELEASE_MINOR -ge $INSTALLED_RELEASE_MINOR ]; then
        if [ $SETUP_RELEASE_MINOR -ne $INSTALLED_RELEASE_MINOR ]; then
            SKIP_FUTHER_CHECKS=0
        fi
    else
        logStatus 7 "Update is not supported for installed Minor-Release"
    fi

    if [ $SKIP_FURTHER_CHECKS -eq 0 ] || [ $SETUP_DVD -ge $INSTALLED_DVD ]; then
        if [ $SETUP_DVD -ne $INSTALLED_DVD ]; then
            SKIP_FURTHER_CHECKS=0
        fi
    else
        logStatus 7 "Update is not supported for installed DVD"
        return 2
    fi

    if [ $SKIP_FURTHER_CHECKS -eq 0 ] || [ $SETUP_HOTFIX_MAJOR -ge $INSTALLED_HOTFIX_MAJOR ]; then
        if [ $SETUP_HOTFIX_MAJOR -eq $INSTALLED_HOTFIX_MAJOR ]; then
            if [ $SETUP_HOTFIX_MINOR -lt $INSTALLED_HOTFIX_MINOR ]; then
                logStatus 7 "A newer hotfix is already installed"
            fi
        else
            SKIP_FURTHER_CHECKS=0
        fi
    else
        logStatus 2 "A newer hotfix is already installed"
    fi
    
    logInfo "Software repository verification complete, version update is valid, continue..." 

    logDebug "Returning from function '$FUNCNAME'..."

} # end: checkSwPath


# Check if a new version of UpdateAllNodes is available in new software
newScriptExists()
{
   logDebug "Entering function '$FUNCNAME'..."

   rpm_name=`find $SYNCH_REPO -name "scs_patchtools*.rpm"`
   zip_name="/opt/siemens/sw_repository/scs_patchtools.zip"

   if [ -z $rpm_name ]; then
      logInfo "New patchtools RPM not found in $SYNCH_REPO, no patch needed, continue.."
   else
       logInfo "New patchtools RPM found in $SYNCH_REPO, compare files"
       this_zip_md5=`md5sum "$zip_name" | awk '{ print $1}'`

       rpm2cpio $rpm_name | cpio -ivd ".$zip_name" 1>>$LOGFILE 2>&1
       ret_val=$?
       if [ $ret_val -ne 0 ]; then
          logStatus 1 "Cannot extract zip from $rpm_name"
       else
          new_zip_md5=`md5sum ".$zip_name" | awk '{ print $1}'`
          rm -rf "`pwd`/opt" 1>>$LOGFILE 2>&1
          if [ "$this_zip_md5" == "$new_zip_md5" ]; then
             logInfo "Files identical, no patch needed, continue"
          else
             logInfo "Files differ, patch needed"
             rpm -i --force $rpm_name 1>>$LOGFILE 2>&1
             exec $FULLSCRIPTNAME $COMMAND $REPOSITORY 1>>$LOGFILE 2>&1
          fi
       fi
   fi

   logDebug "Returning from function '$FUNCNAME'..."
} # end: newScriptExists

# if new repository is not defined, use old existing repositories for the update
useExistingRepo()
{
   logDebug "Entering function '$FUNCNAME'..."
   
   if [ -f $UPDATE_REPO/support/update.sh ]; then
      logInfo "Using existing update repo, seems that previous update was hotfix"
      SYNCH_REPO="$UPDATE_REPO"
      UPDATE_TYPE="hotfix"
   elif [ -f $BASE_REPO/support/update.sh ]; then
      logInfo "Using existing base repo, seems that previous update was major/minor fix"
      SYNCH_REPO="$BASE_REPO"
      UPDATE_TYPE="major"
   else
      logStatus 1 "Update script could not found neither in $BASE_REPO not in $UPDATE_REPO repo" 
   fi

   if ! getSetupVersion; then
      logStatus 6 "Could not detect setup version, existing repository is not valid"
   fi

   logDebug "Returning from function '$FUNCNAME'..."
} # end: useExistingRepo


# Change the "message of the day" on all nodes
changeMsgOftheDay()
{
   logDebug "Entering function '$FUNCNAME'..."
   
   local cpout1="/tmp/cpout1.log"
   local cpout2="/tmp/cpout2.log"

   # text indicating that the system is being updated (this will be shown to anyone that logs on to one of the nodes).
   
   cp /etc/issue.net /etc/issue.net.bkp 1>>$LOGFILE 2>&1
   cp /etc/motd /etc/motd.bkp           1>>$LOGFILE 2>&1
   cp -fp /etc/issue /etc/issue.net     1>>$LOGFILE 2>&1

   message="########### ATTENTION: UPDATE IN PROGRESS ##########"

   echo "$message" >> /etc/issue.net # network access
   echo "$message" >> /etc/motd      # console access
   logInfo "Message of the day changed successfully on $BACKEND"

   for (( i = 0 ; i < ${#NODES[@]} ; i++ ))
   do
     ssh root@${NODES[$i]} "cp /etc/issue.net /etc/issue.net.bkp;cp /etc/motd /etc/motd.bkp;cp -fp /etc/issue /etc/issue.net" 1>$cpout1 2>/dev/null
     ret_val=$?
     if [ $ret_val -ne 0 ]; then
        cat $cpout1 >>$LOGFILE
        logStatus 1 "Cannot backup /etc/issue.net /etc/motd files on ${NODES[$i]}"
     else
        ssh root@${NODES[$i]} "echo '"$message"' >> /etc/issue.net;echo '"$message"' >> /etc/motd" 1>$cpout2 2>/dev/null
        ret_val="$?"
        if [ $ret_val -ne 0 ]; then
           cat $cpout2 >>$LOGFILE
           logStatus 1 "Failed to change the message of the day on ${NODES[$i]}" 
        else
           logInfo "Message of the day changed successfully on ${NODES[$i]}"
        fi
     fi
   done
   rm -rf $cpout1 $cpout2 1>>$LOGFILE 2>&1
   logDebug "Returning from function '$FUNCNAME'..."

} # end: changeMsgOftheDay


# remove the "message of the day" on all nodes
removeMsgOftheDay()
{
   logDebug "Entering function '$FUNCNAME'..."

   if [ "$SYNC_FAIL" -eq 1 ]; then
      logInfo "Restore message of the day not needed, early failure in synchronization"
   else
      local cpout="/tmp/cpout.log"

      # remove the message of the day indicating an update in progress in all nodes
      # restore backup files 
      mv /etc/issue.net.bkp /etc/issue.net 1>>$LOGFILE 2>&1
      mv /etc/motd.bkp /etc/motd	   1>>$LOGFILE 2>&1
      logInfo "Message of the day restored successfully on $BACKEND"

      for (( i = 0 ; i < ${#NODES[@]} ; i++ ))
      do
        ssh root@${NODES[$i]} "mv /etc/issue.net.bkp /etc/issue.net;mv /etc/motd.bkp /etc/motd" 1>$cpout 2>/dev/null
        ret_val="$?"
        if [ $ret_val -ne 0 ]; then
           cat $cpout >>$LOGFILE
           logStatus 1 "Failed to restore message of the day on ${NODES[$i]}"
        else
           logInfo "Message of the day restored successfully on ${NODES[$i]}"
        fi
      done
   
      rm -rf $cpout 1>>$LOGFILE 2>&1
   fi
   logDebug "Returning from function '$FUNCNAME'..."

} # end: removeMsgOftheDay

# update backend
updateBackend()
{
   logDebug "Entering function '$FUNCNAME'..."

   local update_path="$SYNCH_REPO/support/update.sh"

   bash $update_path $UPDATE_TYPE $BASE_REPO $UPDATE_REPO $update_path 1>/dev/null 2>>$LOGFILE &
 
   local update_pid=$!  
   logDebug "Update script envoked (pid=$update_pid) successfully in local node $BACKEND" 

   writeStatus new "$BACKEND(BACKEND):Update script started successfully"
   for (( i = 0 ; i < ${#NODES[@]} ; i++ ))
   do
      writeStatus append "${NODES[$i]}(${NTYPES[$i]}):Symphonia stopped, waiting update on backend"
   done

   logDebug "Returning from function '$FUNCNAME'..."
}

# check content of status file of the actual update script (OK/ERROR/PROGRESS)
checkLocalStatus()
{
   logDebug "Entering function '$FUNCNAME'..."
   local statusMissing=0   

   while [ $statusMissing -lt 2 ]
   do
   if [ -f "$UPDATE_STATUSFILE" ]; then
      local REPORT=`cat $UPDATE_STATUSFILE`
      case "$REPORT" in
           "PROGRESS")
                      logInfo "Update is still running on local node $BACKEND"
                      return 2
                      ;;
              "ERROR")
                      logDebug "Update has been finished on local node $BACKEND but failed"
                      return 1
                      ;;
                 "OK")
                      logDebug "Update has been finished successfully on local node $BACKEND"
                      return 0
                      ;;
                   *)
                      logWarn "Unknown error, status '$REPORT' of update in local node $BACKEND in not expected"
                      return 4
                      ;;
       esac
       statusMissing=0
   else
       logDebug "Status file not generated yet, sleep and retry"
       statusMissing=`expr $statusMissing + 1`
       sleep 5
   fi  
   done
   
   logInfo "No status file found on local node $BACKEND"
   return 3
    
   logDebug "Returning from function '$FUNCNAME'..."

} # checkLocalStatus


# monitor local update to complete
monitorLocalUpdate()
{
  logDebug "Entering function '$FUNCNAME'..."
  
  local errReport
  
  while true
  do
    checkLocalStatus
    local ret=$?
    case "$ret" in
           0)
             logInfo "Local update finished successfully, continue"
             break 
             ;;
           1)
             errReport="$BACKEND(BACKEND):Update failed"
             break
             ;;
           2)
             logInfo "Sleep 30sec and retry to determine update status"
             sleep 30
             ;;
           *)
             errReport="$BACKEND(BACKEND):Unknown failure while checking update status (return code $ret)"
             break
             ;;
      esac
  done

  if [ -n "$errReport" ]; then
      writeStatus new "$errReport"
      for (( i = 0 ; i < ${#NODES[@]} ; i++ ))
      do
         writeStatus append "${NODES[$i]}(${NTYPES[$i]}):Symphonia stopped, no update performed"
      done
      logReport 1 "$errReport"
  fi
  
  logDebug "Returning from function '$FUNCNAME'..."
} # end: monitorLocalUpdate

# start backend
startBackend()
{
   logDebug "Entering function '$FUNCNAME'..."
   
   local errReport
   local reason="successful update"

   if [ "$SYNC_FAIL" -eq 1 ]; then
      logInfo "Restoring local node after failure in synchronization"
      reason="syncronization failure (no update triggered yet)"
   fi

   logInfo "Starting Backend"
   /etc/init.d/symphoniad start 1>>$LOGFILE 2>&1 
   start_ret="$?"
   if [ "$start_ret" -eq 0 ]; then
      writeStatus new "$BACKEND(BACKEND):Symphonia started successfully after $reason"
   else 
      errReport="$BACKEND(BACKEND):Error occured while starting symphonia"
      writeStatus new "$errReport"
      for (( i = 0 ; i < ${#NODES[@]} ; i++ ))
      do
         writeStatus append "${NODES[$i]}(${NTYPES[$i]}):Symphonia still stopped"
      done
      logReport 1 "$errReport"
  fi    
   
  logDebug "Returning from function '$FUNCNAME'..."
} # end: startBackend


# stop symphonia in local BE node and in remote nodes FE/MS
stopSymphonia()
{
   logDebug "Entering function '$FUNCNAME'..."
   local errReport
   local skip=0

   logInfo "Stopping symphonia in local backend node"
   /etc/init.d/symphoniad stop 1>>$LOGFILE 2>&1
   stop_ret="$?"
   if [ "$stop_ret" -ne 0 ]; then
       errReport="$BACKEND(BACKEND):Could not stop symphonia (rcode=$stop_ret)"
       writeStatus new "$errReport"
       for (( i = 0 ; i < ${#NODES[@]} ; i++ ))
       do
          writeStatus append "${NODES[$i]}(${NTYPES[$i]}):Symphonia still running"
       done
       logReport 1 "$errReport"
   else
       writeStatus new "$BACKEND(BACKEND):Symphonia stopped successfully"
   fi

   if [ "$SINGLE_NODE" -eq 0 ]; then
     logInfo "Stopping symphonia in remote nodes (Frontend and MediaServer)"
     for (( i = 0 ; i < ${#NODES[@]} ; i++ ))
     do
        ssh root@${NODES[$i]} /etc/init.d/symphoniad stop 1>>$LOGFILE 2>&1
        stop_ret="$?"
        if [ "$stop_ret" -eq 0 ]; then
           writeStatus append "${NODES[$i]}(${NTYPES[$i]}):Symphonia stopped successfully"
        else 
           errReport="${NODES[$i]}(${NTYPES[$i]}):Could not stop symphonia (rcode=$stop_ret)"
           writeStatus append "$errReport"
        fi
     done
   fi

   if [ -n "$errReport" ]; then
       logReport 1 "Symphonia failed to stop in at least one remote node"
   fi
   
   # no need to check again with 'status' argument, symphonia stop returns after a status check.
   logDebug "Returning from function '$FUNCNAME'..."
}


# start FE/MS 
startFrontendMedia()
{
   logDebug "Entering function '$FUNCNAME'..."

   if [ "$SINGLE_NODE" -eq 1 ]; then
      logDebug "None remote node found, skip starting symphonia in remote nodes"
      return
   fi
   
   local errReport
   local reason="successful update"

   if [ "$SYNC_FAIL" -eq 1 ]; then
      logInfo "Restoring remote nodes after failure in synchronization"
      reason="syncronization failure (no update triggered yet)"
   fi
  
   writeStatus new "$BACKEND(BACKEND):Symphonia started successfully after $reason"
 
   logInfo "Starting symphonia in remote nodes (Frontend and MediaServer)"
   for (( i = 0 ; i < ${#NODES[@]} ; i++ ))
   do
      ssh root@${NODES[$i]} /etc/init.d/symphoniad start 1>>$LOGFILE 2>&1
      start_ret="$?"
      if [ "$start_ret" -eq 0 ]; then
         writeStatus append "${NODES[$i]}(${NTYPES[$i]}):Symphonia started successfully after $reason"
      else
         errReport="${NODES[$i]}(${NTYPES[$i]}):Could not start symphonia after $reason"
         writeStatus append "$errReport"
      fi
   done

   if [ -n "$errReport" ]; then
       logReport 1 "Symphonia failed to start in at least one remote node after $reason"
   else
       if [ "$SYNC_FAIL" -eq 0 ]; then
          writeStatus append "Date '`date +%Y/%m/%d-%H:%M`' || Installed Version '$SETUP_STRING_VERSION' || Used Repository path '$REPOSITORY'"
       fi
   fi
   # no need to check again with 'status' argument, symphoniad start returns after a status check.
   # no need to check if symphonia is already started (fallback case), symphoniad does it.

   logDebug "Returning from function '$FUNCNAME'..."

} # end: startFrontendMedia

# run update script remotely
updateFrontendMedia()
{
   logDebug "Entering function '$FUNCNAME'..."

   if [ "$SINGLE_NODE" -eq 1 ]; then
      logDebug "None remote node found, skip update start"
      return
   fi

   local LOCAL=""
   if [[ $BACKEND =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]];then
     LOCAL=`hostname -f`
   else
      LOCAL=$BACKEND
   fi

   local REMBASE_REPO="https://$LOCAL:444$BASE_REPO/"
   local REMUPDATE_REPO="https://$LOCAL:444$UPDATE_REPO/"
   local errReport
   local skip=0
   
   for (( i = 0 ; i < ${#NODES[@]} ; i++ ))
   do
      if [ $skip -eq 0 ]; then
         scp -o ConnectTimeout=4 $SYNCH_REPO/support/update.sh root@${NODES[$i]}:/tmp/update.sh >>$LOGFILE 2>&1 
         ret="$?"
         if [ "$ret" -ne 0 ]; then
            errReport="${NODES[$i]}(${NTYPES[$i]}):Error occured while copying update script"
            writeStatus append "$errReport"
            skip=1
         fi
      fi

      if [ $skip -eq 0 ]; then
         ssh root@${NODES[$i]} "bash /tmp/update.sh $UPDATE_TYPE $REMBASE_REPO $REMUPDATE_REPO /tmp/update.sh &" 1>/dev/null 2>>$LOGFILE 
         ret="$?"
         if [ "$ret" -eq 0 ]; then
            writeStatus append "${NODES[$i]}(${NTYPES[$i]}):Update script started successfully"
         else
            errReport="${NODES[$i]}(${NTYPES[$i]}):Error occured while running update script"
            writeStatus append "$errReport"
            skip=1
         fi
      else
         writeStatus append "${NODES[$i]}(${NTYPES[$i]}):Symphonia is stopped, update script not envoked"
      fi
   done

   if [ -n "$errReport" ]; then
       logReport 1 "$errReport"
   fi
   
   logDebug "Returning from function '$FUNCNAME'..."   
}


# Write short status file with one single line per node 
writeStatus()
{
   logDebug "Entering function '$FUNCNAME'..."
   if [ "$SYNC_FAIL" -eq 0 ]; then
      if [ "$1" == "new" ]; then
         echo -e "$2" > $STATUS_FILE 2>&1
      fi
      if [ "$1" == "append" ]; then
         echo -e "$2" >> $STATUS_FILE 2>&1
      fi
   fi
   logInfo "$2"

   logDebug "Returning from function '$FUNCNAME'..."

} # end: writeStatus

# check content of status file of the actual update script (OK/ERROR/PROGRESS) 
checkRemoteStatus()
{
   logDebug "Entering function '$FUNCNAME'..."

   local REM_NODE=$1

   logDebug "Read contents of update status file from remote node $REM_NODE"
   local REM_STATUS=`ssh root@${REM_NODE} "cat ${UPDATE_STATUSFILE}" 2>/dev/null`

   if [ -n "$REM_STATUS" ]; then
      logDebug "Dumping remote status file contents in logfile :'$REM_STATUS'"

      case "$REM_STATUS" in
           "PROGRESS")
                      logDebug "Update is still running on remote node $REM_NODE"
                      return 2
                      ;;
              "ERROR")
                      logDebug "Update has failed on remote node $REM_NODE"
                      return 1
                      ;;
                 "OK")
                      logDebug "Update has been finished successfully on remote node $REM_NODE"
                      return 0
                      ;;
                   *)
                      logWarn "Status '$REPORT' of update on remote node $REM_NODE is not expected"
                      return 4
                      ;;
      esac
   else
      logWarn "No status file found on remote node $REM_NODE"
      return 3 
   fi

   logDebug "Returning from function '$FUNCNAME'..."
  
} # end:checkRemoteStatus


# monitor the update process in remote nodes
monitorRemoteUpdate()
{
   logDebug "Entering function '$FUNCNAME'..."

   if [ "$SINGLE_NODE" -eq 1 ]; then
      logDebug "None remote node found, skip monitoring the update process"
      return
   fi
  
   local PENDING=("${NODES[@]}")
   local PTYPE=("${NTYPES[@]}")
   local cntF=0
   local cntP=0
  
   writeStatus new "$BACKEND(BACKEND):Update completed on backend, waiting update on remote nodes"
 
   while true
   do 
      for (( i = 0 ; i < ${#PENDING[@]} ; i++ ))
      do
        if [ "${PENDING[$i]}" != " " ]; then
           checkRemoteStatus "${PENDING[$i]}"
           ret=$?
           case "$ret" in
              0)
                 writeStatus append "${PENDING[$i]}(${PTYPE[$i]}):Update finished successfully"
                 PENDING[$i]=" "
                 PTYPE[$i]=" "
                ;;
              1)
                 errReport="${PENDING[$i]}(${PTYPE[$i]}):Update failed"
                 writeStatus append "$errReport"
                 PENDING[$i]=" "
                 PTYPE[$i]=" "
                 cntF=`expr $cntF + 1`
                ;;
              2)
                 logInfo "Update still in progress on remote node ${PENDING[$i]}, retry later"
                 if [ "$cntP" -ne "$i" ]; then
                    PENDING[cntP]=${PENDING[$i]}
                    PTYPE[cntP]=${PTYPE[$i]}
                    PENDING[$i]=" "
                 fi
                 cntP=`expr $cntP + 1`
                ;;
              *)
                 errReport="${PENDING[$i]}(${PTYPE[$i]}):Unknown failure while checking update status (return code $ret)"
                 writeStatus append "$errReport"
                 PENDING[$i]=" "
                 PTYPE[$i]=" "
                 cntF=`expr $cntF + 1`
                ;;
           esac
        fi
      done
      
      if [ "$cntP" -eq 0 ]; then
         logInfo "Update status of all remote nodes determined"
         break
      else
         cntP=0
         logInfo "Sleeping for 30sec and check update status on remaining nodes again"
         sleep 30
      fi
   done
   
   if [ "$cntF" -eq 0 ]; then    
      logInfo "Last update has been finished on all nodes and was successful"
   else
      logReport 1 "Last update has been finished on all nodes but it failed at least on one node"
   fi

   logDebug "Returning from function '$FUNCNAME'..."

} # end: monitorRemoteUpdate


# If new software delivery is a major release, minor release or a fixrelease replace base repository on the backend 
# with new repository and remove the update repository from the backend.
# Otherwise (new software is a hotfix) replace the update repository on the backend with the new repository on the backend.
isSwHotfix()
{
   logDebug "Entering function '$FUNCNAME'..."
    
   # now check which kind of update we perform
   if [ $SETUP_VERSION -ne $INSTALLED_VERSION ] || [ $SETUP_RELEASE_MAJOR -ne $INSTALLED_RELEASE_MAJOR ] || [ $SETUP_RELEASE_MINOR -ne $INSTALLED_RELEASE_MINOR ] ; then
      logInfo "Major update to be performed"        
      UPDATE_TYPE="major" 
   fi
    
   if [ $SETUP_DVD -ne $INSTALLED_DVD ] || [ $SETUP_HOTFIX_MAJOR -eq 0 ]; then
      logInfo "Minor update to be performed" 
      UPDATE_TYPE="minor"
   fi
   
   if [ -z "$UPDATE_TYPE" ]; then 
      logInfo "Hotfix update to be performed"
      UPDATE_TYPE="hotfix"
   fi

   if [ "$UPDATE_TYPE" == "hotfix" ]; then
      logInfo "Synchronize OSC update repository with new repository '$REPOSITORY'"
      SYNCH_REPO="$UPDATE_REPO"
   else
     logInfo "Remove OSC update repository"
     rm -rf $UPDATE_REPO/* 1>> $LOGFILE 2>&1
     logInfo "Synchronize OSC base repository with new repository '$REPOSITORY'"
     SYNCH_REPO="$BASE_REPO"
   fi

   rsync -hvrlptD --delete $REPOSITORY/ $SYNCH_REPO 1>> $LOGFILE 2>&1 
   ret_val=$?
   if [ $ret_val -ne 0 ]; then
      logStatus 1 "Could not synchronize repositories (rsync eturn code $ret_val)"
   else
      logInfo "Repositories synchronized successful"
   fi

   logDebug "Returning from function '$FUNCNAME'..."

} # end: isSwHotfix 


# check if a trusted relationship already established between nodeBE-nodeFEMS.
# use ssh on the nodeBE without enter a password to get root access on nodeFEMS.
# function equivelant to verifyTrustedCon of prepareUpdate script
checkAllTrustedCon()
{
   logDebug "Entering function '$FUNCNAME'..."

   for (( i = 0 ; i < ${#NODES[@]} ; i++ ))
   do
      logInfo "Verifying trusted ssl connection to ${NODES[$i]}"
      ssh -o "BatchMode=yes" root@${NODES[$i]} "echo 1>/dev/null 2>&1"
      ret_val=$?
      if [ $ret_val -ne 0 ]; then
         logStatus 3 "Secure connection for ${NODES[$i]} has not been established, aborting!!!" 
      else
         logInfo "Secure connection between $BACKEND and ${NODES[$i]} exists, continue..."
      fi 
   done
   
   logDebug "Returning from function '$FUNCNAME'..."

} # end: checkTrustedCon


checkUpdateStatus()
{
   logDebug "Entering function '$FUNCNAME'..."

   logInfo "Check for running instance of the script on local node $BACKEND"
   checkUpdateRunning
   local ret=$?
   if [ "$ret" -eq 1 ]; then
      logInfo "Update in progress in this system"
      logStatus 2 "Update is still running on at least one node"  
   else
      checkLocalStatus
      local ret_local="$?"
      case $ret_local in
            0)
              logInfo "Update of backend completed, continue to check remote nodes as well"
              ;;
            1)
              logStatus 1 "Last update has been finished on backend and failed"
              ;;
            3)
              logStatus 3 "No update has ever been triggered"
              ;;
            *)
              logStatus 4 "Unexpected error occured (return code $ret_local is invalid)"
              ;;
      esac
   fi

   if [ "$SINGLE_NODE" -eq 1 ]; then
      logDebug "None remote node found, skip checking remote update status"
      logStatus 0 "Last update has finished and was successful" 
   fi

   local cntSuccess=0
   local cntFailure=0

   # in this phase, update script is not running, update was successful in backend
   # checking also remote nodes (success/fail/unknown, no chance for pending update)

   for (( i = 0 ; i < ${#NODES[@]} ; i++ ))
   do
      checkRemoteStatus "${NODES[$i]}"
      local ret_remote=$?
      case "$ret_remote" in
              0)
                cntSuccess=`expr $cntSuccess + 1`
                ;;
              1)
                cntFailure=`expr $cntFailure + 1`
                ;;
              *)
                logStatus 4 "Unexpected error occured (return code $ret_remote is invalid)"
                ;;
           esac
   done

   if [ "$cntFailure" -eq 0 ] && [ "$cntSuccess" -eq "${#NODES[@]}" ]; then
      logStatus 0 "Last update has finished on all nodes and was successful "
   fi

   if [ "$cntFailure" -ne 0 ]; then
      logStatus 1 "Last update has finished on all nodes but it failed at least on one remote node"
   fi
   
   logDebug "Returning from function '$FUNCNAME'..."

} # end: checkUpdateStatus

# check if partitioning is activated 
isImagedSystem()
{
   logDebug "Entering function '$FUNCNAME'..."

   logInfo "Checking if partitioning is supported and configured in local node"

   if [ -f "$PARTITION_LOCK" ]; then
      logInfo "Dual partitioning supported, syncUC configured on local node $BACKEND"
   else
      logWarn "Dual partitioning not supported or syncUC not configured on local node $BACKEND"
      return 99
   fi
   
   if [ "$SINGLE_NODE" -eq 0 ]; then
      logInfo "Checking if partitioning is supported and configured in remote nodes as well"
      for (( i = 0 ; i < ${#NODES[@]} ; i++ ))
      do
        if ssh root@${NODES[$i]} 'ls "'$PARTITION_LOCK'" >/dev/null 2>/dev/null'; then
           logInfo "Dual partitioning supported, syncUC configured on remote node ${NODES[$i]}"
        else
           logWarn "Dual partitioning not supported or syncUC not configured on remote node ${NODES[$i]}"    
           return 99 
        fi
      done
   fi
   logDebug "Returning from function '$FUNCNAME'..."
} # end: isImagedSystem


# synch active to passive partitions
synchPartitions()
{
   logDebug "Entering function '$FUNCNAME'..."

   # Check if '-s' argument is used to request synchronization
   if [ "$SYNCH" -eq 1 ]; then
         
      if isImagedSystem; then
         # synchronize active partitions to passive partitions on all nodes by calling syncUC script 
         # wait until it has finished successfully on all nodes.

         logInfo "Calling syncUC script to synchronize active partitions to passive partitions"

         /usr/sbin/syncUC -iy sync 1>>$LOGFILE 2>&1
         ret_val="$?"
         if [ $ret_val -ne 0 ]; then
            logWarn "Synchronization of active to passive partition failed on local node (rcode=$ret_val)"
            SYNC_FAIL=1
         else
            logInfo "Partitions synchronized successfully on local node"
         fi
         
         if [ "$SINGLE_NODE" -eq 0 ]; then
            logInfo "Calling syncUC script in remote nodes"
            for (( i = 0 ; i < ${#NODES[@]} ; i++ ))
            do  
               ssh root@${NODES[$i]} "/usr/sbin/syncUC -iy sync" 1>>$LOGFILE 2>&1
               ret_val="$?"
               if [ $ret_val -eq 0 ]; then
                 logInfo "Partitions synchronized successfully on ${NODES[$i]} node"
               else
                 logWarn "Could not synch active to fallback partition on ${NODES[$i]} node (rcode=$ret_val)"
                 SYNC_FAIL=1
               fi
            done
        fi
      else
         logStatus 1 "Dual partitioning not supported or syncUC not configured in at least one system node"
      fi
 
   else
      logInfo "No synchronization of partitions requested, continue..."
   fi 

   if [ $SYNC_FAIL -eq 1 ]; then
      startBackend
      startFrontendMedia
      logStatus 1 "Synchronization of active to passive partition failed in at least one system node"
   fi

   logDebug "Returning from function '$FUNCNAME'..."

} # end: synchPartitions


# Check if the feature is activated (existence of <logdir>/install/FeatureUI4POA.lock)
isFeatureEnabled()
{
   logDebug "Entering function '$FUNCNAME'..."
   if [ -f "$FEATURE_LOCK" ]; then
      logInfo "UI patching feature activated"   
   else
      logStatus 1 "UI patching feature not activated"
   fi

   logDebug "Returning from function '$FUNCNAME'..."

} # end: isFeatureEnabled


# Collect logfiles of the update script and other installation logs from all nodes 
collectLogs()
{
   logDebug "Entering function '$FUNCNAME'..."
   logDebug "Collect log files in a tar file"  
 
   logInfo "Collecting local backend logs"
   cp $UPDATE_LOGFILE $COLLECTDIR 1>/dev/null 2>&1
   cp $UPDATE_STATUSFILE $COLLECTDIR 1>/dev/null 2>&1

   for (( i = 0 ; i < ${#NODES[@]} ; i++ ))
   do
      logInfo "Collecting remote node ${NODES[$i]} logs"
      scp -o ConnectTimeout=4 root@${NODES[$i]}:$UPDATE_LOGFILE $COLLECTDIR/${NODES[$i]}_0update.log 1>/dev/null 2>&1
      scp -o ConnectTimeout=4 root@${NODES[$i]}:$UPDATE_STATUSFILE $COLLECTDIR/${NODES[$i]}_oscUpdateStatusFile 1>/dev/null 2>&1
   done

   local cdir=`pwd`
   local filelist="prepareUpdate.log updateAllNodes.log updateAllNodes.status check.log status.log"
   cd $COLLECTDIR
   tar cf $REPORT $filelist
   cd $cdir  

   logDebug "Returning from function '$FUNCNAME'..."

} # collectLogs

######################
##       MAIN	    ##
######################

while getopts 'vhs?' option
do
    case $option in
    v) 
       VERBOSE=1
       ;;
    s)
       SYNCH=1
       ;;
    h|?) 
       usage 0
       ;;
    esac
done

shift $(($OPTIND - 1))

if [ -z "$*" ]; then
  echo "No commands/arguments specified"
  exit 99
else
  COMMAND="$1"
  REPOSITORY="$2"
fi


case $COMMAND in
    check) 
           checkLogCleanup
           logInfo "Command 'check' with argument '$REPOSITORY'" 
           getParamFromSystemfile
           if [ -z "$REPOSITORY" ]; then 
              isFeatureEnabled
           else
				exit 7;
              isRootUser
              checkAllTrustedCon
              checkYumAccess
              notUpdateRunning 
              checkSwPath
           fi
           ;;
    update)
           updateLogCleanup
           logInfo "Command 'update' with argument '$REPOSITORY'"
           getParamFromSystemfile
           if [ -n "$REPOSITORY" ]; then
              checkSwPath
              isSwHotfix
              newScriptExists
           else
              useExistingRepo
           fi 
           
           synchPartitions
           deleteHistory
           changeMsgOftheDay
           stopSymphonia
           updateBackend
           monitorLocalUpdate
           startBackend
           
           updateFrontendMedia
           monitorRemoteUpdate
           startFrontendMedia 
           
           logReport 0 "Update successful"
           ;; 
    status)
statusLogCleanup 
           logInfo "Command 'status'"
           getParamFromSystemfile
           checkUpdateStatus 
           ;;
         *)
           echo "$COMMAND is invalid"
           usage 1
           ;;
        
esac
exit
