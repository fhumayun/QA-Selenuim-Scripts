

     /*
	 * BTN_ := Button ID
	 * IPF_ := Input Field ID 
	 * TB_:= Tab ID
	 * RB_: = Radio Button ID
	 * CB_:= Checkbox ID
	 * SLC_:= Selector ID
	 * TEXT_:= Generic Error messages
	 * TEXT_:= 
	 * ARW_:= Arrow ID
	 * LBL_:= Label ID
	 * BD_:= Body ID
	 * TBL_:= Table ID
	 * DIV_ := Div ID
	 * FRN_ := Frame Name
	 * IFR_ := IFrame ID
	 * TD_ := Tabel td ID
	 * XPATH_ := XPath
	 * CLM_ := Column Name
	 */	
	

public interface MediaServerProperties {

String CB_Enable_media_Server = "enableMs";
String BTN_Advanced = "msAdvCellBtn";
String IPF_Time_to_Live = "msAdaptTimeToLive";
	
}
